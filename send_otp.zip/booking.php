<?php
include('db.php');
$code = $_GET['code'];

function generateOrderID()
{
    $orderID = time() . rand(1000, 9999);
    return $orderID;
}

session_start();


if (!isset($_SESSION['user_id']) || !isset($_SESSION['mobile'])) {
    header('Location: login.php?code=' . $code);
    exit();
}
$curl = curl_init();


$user_id = $_SESSION['user_id'];
$mobile = $_SESSION['mobile'];
$user_type = $_SESSION['user_type'];
$name = $_SESSION['name'];
$email = $_SESSION['email'];

$base_url = 'https://portal.glowupwithmanisha.com';
// $base_url = 'http://localhost/CI/event-portal';

curl_setopt_array($curl, array(
    CURLOPT_URL => $base_url . '/index.php/api/Events_api/EvtD',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 0,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => 'POST',
    CURLOPT_POSTFIELDS => array('code' => $code, '_method' => 'post'),
    CURLOPT_HTTPHEADER => array(
        'Cookie: ci_session=40slq6epgmr07cbl6tjfvh3quvp5rsnp'
    ),
));

$response = curl_exec($curl);

curl_close($curl);
$data = json_decode($response, true);
if ($data['status'] == "true") {
    $result = $data['result'];
    $bank_arr = json_decode($result['bank_master_ids'], true);
    ;

    // Check for event expiry
    $event_end_date = $result['end_date']; // Event end date
    $current_date = date('Y-m-d'); // Current date

    if ($current_date < $event_end_date) {

        $event_expired = true;
    } else {
        $event_expired = false;
    }
}
    // print_r($bank_arr['0']);exit;

    // Query to select data from discounts_master table
    curl_setopt_array($curl, array(
        CURLOPT_URL => $base_url . '/index.php/api/Events_api/banklist',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        // CURLOPT_POSTFIELDS => array('code' => $code, '_method' => 'post'),
        CURLOPT_HTTPHEADER => array(
            'Cookie: ci_session=40slq6epgmr07cbl6tjfvh3quvp5rsnp'
        ),
    ));
    
    $response1 = curl_exec($curl);
    
    curl_close($curl);
    $bankdata = json_decode($response1, true);
    $resultbank = $bankdata['result'];
 
    
    

$_SESSION['event_name'] = $result['event_name'];
$_SESSION['start_date'] = $result['start_date'];
$_SESSION['start_time'] = $result['start_time'];
$_SESSION['end_time'] = $result['end_time'];
$_SESSION['end_date'] = $result['end_date'];
$_SESSION['address'] = $result['address'];


?>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Prepare the image file using cURLFile (if file is uploaded)
    if (isset($_FILES['screenshot']) && $_FILES['screenshot']['error'] == 0) {
        $imageFile = $_FILES['screenshot']['tmp_name'];
        $imageName = $_FILES['screenshot']['name'];

        // Set the target directory and file path
        $targetDir = 'screenshots/';
        $targetFile = $targetDir . basename($imageName);
        // Move the uploaded file to the target directory
        if (move_uploaded_file($imageFile, $targetFile)) {
            // File uploaded successfully
            $payment_screenshot = $targetFile; // Store the file path for further use
        } else {
            // File upload failed
            $payment_screenshot = null;
            echo "Sorry, there was an error uploading your file.";
        }
    } else {
        $payment_screenshot = null;
    }

    $selected_event_types = $_POST['event_type'];
    $selected_packages = $_POST['package_selection'] ?? [];
    $single_prices = $_POST['single_price'] ?? [];
    $package_amounts = $_POST['package_amount'] ?? [];

    $final_data = [];

    foreach ($selected_event_types as $event_id => $event_type) {
        if (isset($selected_packages[$event_id])) {
            $final_data[] = [
                'event_type' => $event_type,
                'selected_package' => $selected_packages[$event_id],
                'amount' => $package_amounts[$event_id],
            ];
        } elseif (isset($single_prices[$event_id])) {
            $final_data[] = [
                'event_type' => $event_type,
                'price' => $single_prices[$event_id],
            ];
        }
    }

    $packageDetailsJson = json_encode($final_data);

    // Extract other form data
    $event_code = $_POST['event_code'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $gender = $_POST['gender'];
    $category_type = $_POST['category_type'];
    $subcategory_type = $_POST['subcategory_type'];
    $company_name = $_POST['company_name'];
    $city = $_POST['city'];
    $state_name = $_POST['state_name'];
    $pincode = $_POST['pincode'];
    $lead_src = $_POST['lead_source'];
    if ($lead_src == 'Others') {
        $lead_source = $_POST['lead_source_others'];
    } else {
        $lead_source = $lead_src;
    }
    $area_interest = $_POST['area_interest'];
    if ($area_interest == 'Others') {
        $area_of_interest = $_POST['area_interest_others'];
    } else {
        $area_of_interest = $area_interest;
    }

    $no_of_tickets = $_POST['no_of_tickets'];
    $total_amount = $_POST['total_amount'];
    $net_total = $_POST['net_payable_total'];
    $advanced_pay = $_POST['Advance'];
    $remaining_amount = $_POST['remaining_amount'];
    $payment_mode = 'Online';
    $coupon_code = $_POST['coupon_code'];
    $discount_value = $_POST['coupon_value'];
    $payment_reference_no = $_POST['payment_ref_no'];
    $booking_date = date('Y-m-d', strtotime($_POST['booking_date']));
    $payment_status = 'Pending';
    $booking_status = 'Pending';
    $order_id = generateOrderID();
    $transaction_date = date('Y-m-d'); // For the current date

    // Insert into the bookings table using mysqli
    $sql = "INSERT INTO `bookings` 
    (`order_id`, `transaction_date`, `user_id`, `event_code`, `booking_date`, `package_type`, `total_amount`, `discount_value`, `coupon_code`, `net_total`, `no_of_tickets`, `advanced_pay`, `remaining_amount`, `payment_mode`, `payment_reference_no`, `payment_screenshot`, `payment_status`, `area_of_interest`, `lead_source`, `booking_status`, `packageDetails`) 
    VALUES ( '$order_id ','$transaction_date', '$user_id', '$event_code', '$booking_date', '$packageDetailsJson', '$total_amount', '$discount_value', '$coupon_code', '$net_total', '$no_of_tickets', '$advanced_pay', '$remaining_amount', '$payment_mode', '$payment_reference_no', '$payment_screenshot', '$payment_status', '$area_of_interest', '$lead_source', '$booking_status', '$packageDetailsJson' )";

    if ($conn->query($sql) === TRUE) {

        $_SESSION['order_id'] = $order_id;
        $_SESSION['booking_date'] = $booking_date;
        $_SESSION['no_of_tickets'] = $no_of_tickets;
        $_SESSION['net_payable_total'] = $net_total;
        $_SESSION['advanced_pay'] = $advanced_pay;
        $_SESSION['remaining_amount'] = $remaining_amount;
        $_SESSION['city'] = $city;
        $_SESSION['state_name'] = $state_name;
        $_SESSION['coupon_value'] = $discount_value;
        $_SESSION['selected_event_types'] = $selected_event_types;
        header('Location: thankyou.php?code=' . $event_code);
    } else {
        echo "Error saving booking: " . $conn->error;
    }

    $conn->close();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $result['event_name'] ?> || Event Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crorigin>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- #region -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        .head {
            background-color: #000;

        }

        body {

            font-optical-sizing: auto;
            font-weight: 600;
            font-style: normal;
            font-variation-settings:
                "wdth" 100;
            background-color 0.5s ease;
        }


        /* Header Style */
        .header {
            width: 100%;
            background-color: black;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 80px;
        }

        .logo-container img {
            max-width: 100px;
            padding-left: 5px;
        }

        .header .btn-container {
            display: flex;
            gap: 15px;
        }

        .header .btn-container .btn {
            /* background-color: #bb9433; */
            color: white;
            border: none;
            padding: 8px 10px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        .button {
            background-color: #ee2828;
            color: white;
            border: none;
            padding: 8px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
        }

        .button:hover {
            background-color: #ca2424;
        }

        .header .btn-container .btn:hover {
            background-color: #a0822e;
        }

        .event-expired-message {
            background-color: #d9534f;
            color: white;
            padding: 20px 30px;
            text-align: center;
            font-weight: bold;
            font-size: 32px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 600px;
            text-transform: uppercase;
            letter-spacing: 2px;

        }

        .center-container {
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 24px 78px;
        }
        .event-details .qr-code-container img {
        max-width: 90%;
        height: auto;
        max-height: 200px;
        margin-top: -220px;
        margin-left: 7px;
    }
        @media (min-width: 768px) {
            .container {
                flex-direction: row;
            }

            .image-container {
                margin-right: 40px;
                margin-bottom: 0;
            }

            .details {
                text-align: left;
            }

            /* img {
                max-width: 200px;
            } */

            .logo-container img {
                max-width: 160px;
            }


        }

        /* Responsive adjustments */
        @media (max-width: 767px) {
            .container {
                max-width: 100%;
            }

            .image-container img {
                max-width: 100%;
            }

            .header {
                padding: 5px 5px;
            }

            .logo-container img {
                max-width: 70px;
            }


        }

        footer {
            background-color: #555;
            color: white;
            padding: 30px;
            width: 100%;
        }

        .logout_icon {
            width: 20%;
        }

        .footer_v1 .container1 {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .footer_v1 .row {
            width: 100%;
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .footer_v1 .col-sm-6 {
            flex: 0 0 48%;

            padding: 0 10px;
        }

        .footer_v1 .widget-title {
            font-size: 25px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .footer_v1 .textwidget custom-html-widget ul {
            list-style-type: none;
            padding-left: 0;

            padding: 5px;
        }

        .footer_v1 .textwidget custom-html-widget li {
            margin-bottom: 8px;

        }

        .footer_v1 .textwidget.custom-html-widget a {
            color: white;
            font-weight: 600;
            text-decoration: none;
        }

        .footer_v1 .textwidget.custom-html-widget a:hover {
            text-decoration: underline;
            color: white;
        }

        .footer_v1 .textwidget custom-html-widget a:hover {
            text-decoration: underline;
        }


        .footer_v1 .wrap_bellow {
            background-color: black;

            color: white;
        }

        .footer_v1 .wrap_bellow .container1 .row {
            justify-content: center;
            text-align: center;
        }

        .footer_v1 .wrap_bellow .container1 .row .col-sm-12 {
            margin-top: 10px;
        }

        .hide {
            display: none;
        }

        .col-3 {
            display: flex;
            justify-content: flex-start;
            margin: 15px;
        }

        @media (max-width: 576px) {

            .col-9,
            .col-3 {
                flex: 0 0 100%;
                max-width: 100%;
            }

            .col-3 .btn {
                width: 30%;
            }
             

        }
        .jkp{
            
            background-color: #c0aa74;
            border-color: #c0aa74;
            padding: 5px;
            border-radius: 8px;
          
            
        }
    </style>
</head>

<body>


    <div class="header">
        <div class="logo-container">
            <img src="logo-gwm.jpg" class="logo" alt="Logo">
        </div>

        <!-- Center Buttons -->
        <div class="btn-container">
            <a href="https://glowupwithmanisha.com/" class="btn"> Website</a>
            <a href="https://portal.glowupwithmanisha.com/" class="btn"> Profile</a>
        </div>
        <div class="btn-container text-center">
            <a href="logout.php" style="color:#fff;text-decoration:none;"> <img src="image/logout.png"
                    class="logout_icon"></a>
        </div>

    </div>

    <div class="container-fluid">
        <div class="row content">
            <div class="col-md-5 sidenav">

                <div class="event-details">
                    <p><strong>Event Name:</strong> <?= $result['event_name'] ?></p>
                    <p><strong>Start Date:</strong>
                        <?= date('d-M-y', strtotime($result['start_date'])) . ',' . date('h:i a', strtotime($result['start_time'])) ?>
                    </p>
                    <p><strong>End Date:</strong>
                        <?= date('d-M-y', strtotime($result['end_date'])) . ',' . date('h:i a', strtotime($result['end_time'])) ?>
                    </p>
                    <p><strong>Venue:</strong> <a href="https://g.co/kgs/uLLDqfF" target="_blank">Udaipur</a></p>
                    <p><strong>Address :</strong> <a href="https://g.co/kgs/uLLDqfF" target="_blank">Udaipur</a></p>
                    <p><strong>Contact No:</strong> +91 9820490762 / +91 9820490460</p>
                    <p><strong>Email:</strong> <a
                            href="mailto:jayeshpatel.muskowl@gmail.com">jayeshpatel.muskowl@gmail.com</a></p>
                </div>
                <div class="img greebie_image">
                    <img src="head.jpg" style="width:100%;">
                </div>
                <hr>
                <h4> Bank Details</h4>
                <hr>
                <?php foreach ($resultbank as $key=>  $bank_master) { ?>
                    <div class="event-details">
                        <p><strong>Bank Name:</strong> <?= $bank_master['bank_name'] ?></p>
                        <p><strong>Account Number:</strong> <?= $bank_master['account_no'] ?></p>
                        <p><strong>IFSC:</strong> <?= $bank_master['ifsc'] ?></p>
                        <p><strong>Branch:</strong><?= $bank_master['branch_address'] ?></p>
                        <p><strong>UPI Id:</strong><?= $bank_master['upi_id'] ?></p>
                        <div class="qr-code-container qr_image" name="qr-code">
                            <img src="<?=$bank_master['qr_code'] ?>" id="download-qr">
                            <button class="jkp qr_btn text-white "><i class="bi bi-download"></i> download QR</button>
                        </div>
                    </div>
                <?php } ?>
            </div>

            <div class="col-md-7 p-3">
                <!-- <div class="img greebie_image" >
                    <img src="freebie2.png" style="width:100%;">
                </div> -->
                <?php if ($event_expired): ?>
                    <div class="center-container text-center">
                        <div class="event-expired-message">
                            <h2>Event Expired</h2>
                        </div>
                    </div>
                <?php else: ?>
                    <h2>Event Registration Form</h2>
                    <hr>
                    <form action="" method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="event_code" value="<?= $result['identity_code'] ?>">
                        <div class="row mb-2">
                            <div class="col-md-6">
                                <label for="gender">Participant Name</label>
                                <input type="text" id="name" name="name" placeholder="Enter Company Name"
                                    class="form-control" value="<?= $name ?>" readonly>
                            </div>
                            <div class="col-md-6">
                                <label for="name">Email </label>
                                <input type="text" name="email" placeholder="Enter Email " class="form-control"
                                    value="<?= $email ?>" readonly>
                            </div>
                        </div>

                        <div class="row mb-2">
                            <div class="col-md-6">
                                <label for="gender">Mobile Number </label>
                                <input type="text" name="mobile" placeholder="Enter Mobile" class="form-control"
                                    value="<?= $mobile ?>" readonly>
                            </div>
                            <div class="col-md-6">
                                <label for="gender">Gender <span class="required-icon">*</span></label>
                                <div>
                                    <input type="radio" name="gender" value="Male"> Male
                                    &nbsp; &nbsp; &nbsp;
                                    <input type="radio" name="gender" value="Female"> Female
                                </div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-md-6">
                                <label for="category-type">Category <span class="required-icon">*</span></label>
                                <select id="category-type" name="category_type" class="form-control">
                                    <option value="" disabled selected>Choose Category</option>
                                    <option value="Salon">Salon</option>
                                    <option value="Spa">Spa</option>
                                    <option value="Nail Studio">Nail Studio</option>
                                    <option value="Parlour">Parlour</option>
                                    <option value="Association">Association</option>
                                    <option value="Manufacturer">Manufacturer</option>
                                    <option value="Distributor">Distributor</option>
                                    <option value="Wholesaler">Wholesaler</option>
                                    <option value="Retailer">Retailer</option>
                                    <option value="Freelancer">Freelancer</option>
                                    <option value="Academy">Academy</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="category-type">Sub Category <span class="required-icon">*</span></label>
                                <select id="category-type" name="subcategory_type" class="form-control">
                                    <option value="" disabled selected>Choose Sub Category</option>
                                    <option value="Salon">Salon</option>
                                    <option value="Spa">Spa</option>
                                    <option value="Nail Studio">Nail Studio</option>
                                    <option value="Parlour">Parlour</option>
                                    <option value="Association">Association</option>
                                    <option value="Manufacturer">Manufacturer</option>
                                    <option value="Distributor">Distributor</option>
                                    <option value="Wholesaler">Wholesaler</option>
                                    <option value="Retailer">Retailer</option>
                                    <option value="Freelancer">Freelancer</option>
                                    <option value="Academy">Academy</option>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-md-6">
                                <label for="name">Company Name </label>
                                <input type="text" name="company_name" placeholder="Enter Company Name"
                                    class="form-control">
                            </div>
                            <div class="col-md-6">
                                <label for="state">City <span class="required-icon">*</span></label>
                                <input type="text" name="city" placeholder="Enter City" class="form-control">
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-md-6">
                                <label for="name">State </label>
                                <select name="state_name" id="indian-states" class="form-control">
                                    <option value="">Choose State</option>
                                    <option value="andhra-pradesh">Andhra Pradesh</option>
                                    <option value="arunachal-pradesh">Arunachal Pradesh</option>
                                    <option value="assam">Assam</option>
                                    <option value="bihar">Bihar</option>
                                    <option value="chhattisgarh">Chhattisgarh</option>
                                    <option value="goa">Goa</option>
                                    <option value="gujarat">Gujarat</option>
                                    <option value="haryana">Haryana</option>
                                    <option value="himachal-pradesh">Himachal Pradesh</option>
                                    <option value="jharkhand">Jharkhand</option>
                                    <option value="karnataka">Karnataka</option>
                                    <option value="kerala">Kerala</option>
                                    <option value="madhya-pradesh">Madhya Pradesh</option>
                                    <option value="maharashtra">Maharashtra</option>
                                    <option value="manipur">Manipur</option>
                                    <option value="meghalaya">Meghalaya</option>
                                    <option value="mizoram">Mizoram</option>
                                    <option value="nagaland">Nagaland</option>
                                    <option value="odisha">Odisha</option>
                                    <option value="punjab">Punjab</option>
                                    <option value="rajasthan">Rajasthan</option>
                                    <option value="sikkim">Sikkim</option>
                                    <option value="tamil-nadu">Tamil Nadu</option>
                                    <option value="telangana">Telangana</option>
                                    <option value="tripura">Tripura</option>
                                    <option value="uttar-pradesh">Uttar Pradesh</option>
                                    <option value="uttarakhand">Uttarakhand</option>
                                    <option value="west-bengal">West Bengal</option>

                                    <!-- Union Territories -->
                                    <option value="andaman-nicobar">Andaman and Nicobar Islands</option>
                                    <option value="chandigarh">Chandigarh</option>
                                    <option value="dadra-nagar-haveli-daman-diu">Dadra and Nagar Haveli and Daman and Diu
                                    </option>
                                    <option value="delhi">Delhi</option>
                                    <option value="lakshadweep">Lakshadweep</option>
                                    <option value="puducherry">Puducherry</option>
                                    <option value="ladakh">Ladakh</option>
                                    <option value="jammu-kashmir">Jammu and Kashmir</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="pincode">Pincode <span class="required-icon">*</span></label>
                                <input type="text" name="pincode" id="pincode" placeholder="Enter Pincode"
                                    class="form-control">
                            </div>

                        </div>

                        <div class="row mb-2">
                            <div class="col-md-6">

                                <label for="lead-source">Lead Source Master <span class="required-icon">*</span></label>
                                <select id="lead-source" name="lead_source" class="form-control mb-2">
                                    <option value="" disabled selected>Select an option</option>
                                    <option value="Friends Reference">Friends Reference</option>
                                    <option value="GWM Instagram Page">GWM Instagram Page</option>
                                    <option value="GWM Facebook Page">GWM Facebook Page</option>
                                    <option value="Mehndi Marathon 24 Instagram Page">Mehndi Marathon 24 Instagram Page
                                    </option>
                                    <option value="Mehndi Marathon 24 Facebook Page">Mehndi Marathon 24 Facebook Page
                                    </option>
                                    <option value="GWM Website">GWM Website</option>
                                    <option value="GWM WhatsApp">GWM WhatsApp</option>
                                    <option value="Ads Campaign">Ads Campaign</option>
                                    <option value="Google Ads">Google Ads</option>
                                    <option value="YouTube">YouTube</option>
                                    <option value="SMS">SMS</option>
                                    <option value="Email Marketing">Email Marketing</option>
                                    <option value="Tele Calling">Tele Calling</option>
                                    <option value="LinkedIn">LinkedIn</option>
                                    <option value="Artists Page">Artists Page</option>
                                    <option value="Others" id="lead-source-other">Others</option>
                                </select>
                                <input type="text" id="lead-source-others" name="lead_source_others" style="display: none;"
                                    class="form-control" placeholder="Please specify">
                            </div>
                            <div class="col-md-6">
                                <label for="area-interest">Area of Interest <span class="required-icon">*</span></label>
                                <select id="area-interest" name="area_interest" class="form-control mb-2">
                                    <option value="" disabled selected>Select area of interest</option>
                                    <option value="Competitions">Competitions</option>
                                    <option value="Discounts">Discounts</option>
                                    <option value="B2B Meetings / Networking">B2B Meetings / Networking</option>
                                    <option value="Salon & Spa">Salon & Spa</option>
                                    <option value="Equipment Supply Chain">Equipment Supply Chain</option>
                                    <option value="Products Supply Chain">Products Supply Chain</option>
                                    <option value="Make-up">Make-up</option>
                                    <option value="Skin Care">Skin Care</option>
                                    <option value="Products Branding & Marketing">Products Branding & Marketing</option>
                                    <option value="Product Knowledge">Product Knowledge</option>
                                    <option value="Product Awareness">Product Awareness</option>
                                    <option value="Education">Education</option>
                                    <option value="Hair Care">Hair Care</option>
                                    <option value="Nail Art">Nail Art</option>
                                    <option value="Others">Others</option>
                                </select>
                                <input type="text" id="category-others" name="area_interest_others" style="display: none;"
                                    class="form-control" placeholder="Please specify">
                            </div>
                        </div>
                        <hr>
                        <h2>Event Type </h2>
                        <input type="hidden" id="event_type" name="event_type" value="">
                        <!-- You can set a default value or keep it empty -->
                        <hr>
                        <div class="row">
                            <div class="col-md-6">
                                <label for="area-interest"> Booking Date<span class="required-icon">*</span></label>
                                <input type="date" id="booking_date" name="booking_date" class="form-control"
                                    min="<?php echo date('Y-m-d'); ?>">
                            </div>
                        </div>


                        <?php $i = 0;
                        foreach ($result['event_types_details'] as $event_type_arr) {
                            $i++; ?>
                            <div class="row mb-2">
                                <div class="col-md-6">
                                    <div class="field-container">
                                        <div class="checkbox-container">
                                            <div class="checkbox-item">
                                                <input type="checkbox" id="event-<?= $event_type_arr['id'] ?>"
                                                    name="event_type[<?= $event_type_arr['id'] ?>]"
                                                    value="<?= $event_type_arr['event_type'] ?>">
                                                <label for="event-<?= $event_type_arr['id'] ?>">
                                                    <?= $event_type_arr['event_type'] ?>
                                                    <?php if ($event_type_arr['package_available'] != 'Yes') { ?>
                                                        - ₹<?= $event_type_arr['single_price'] ?><?php } ?>
                                                </label>
                                            </div>

                                            <?php if (strcasecmp($event_type_arr['package_available'], 'Yes') == 0) { ?>
                                                <div class="package-selection" id="package-selection-<?= $event_type_arr['id'] ?>"
                                                    style="display: none;">
                                                    <input type="hidden" name="package_amount[<?= $event_type_arr['id'] ?>]"
                                                        class="package_amount" />
                                                    <div class="checkbox-item">
                                                        <input type="radio" id="package-vip-<?= $event_type_arr['id'] ?>"
                                                            name="package_selection[<?= $event_type_arr['id'] ?>]" value="VIP"
                                                            data-fee="<?= $event_type_arr['vip_row_price'] ?>">
                                                        <label for="package-vip-<?= $event_type_arr['id'] ?>">VIP -
                                                            ₹<?= $event_type_arr['vip_row_price'] ?></label>
                                                    </div>
                                                    <div class="checkbox-item">
                                                        <input type="radio" id="package-gold-<?= $event_type_arr['id'] ?>"
                                                            name="package_selection[<?= $event_type_arr['id'] ?>]" value="Gold"
                                                            data-fee="<?= $event_type_arr['gold_row_price'] ?>">
                                                        <label for="package-gold-<?= $event_type_arr['id'] ?>">Gold -
                                                            ₹<?= $event_type_arr['gold_row_price'] ?></label>
                                                    </div>
                                                    <div class="checkbox-item">
                                                        <input type="radio" id="package-silver-<?= $event_type_arr['id'] ?>"
                                                            name="package_selection[<?= $event_type_arr['id'] ?>]" value="Silver"
                                                            data-fee="<?= $event_type_arr['silver_row_price'] ?>">
                                                        <label for="package-silver-<?= $event_type_arr['id'] ?>">Silver -
                                                            ₹<?= $event_type_arr['silver_row_price'] ?></label>
                                                    </div>
                                                </div>
                                                <input type="hidden" name="package_price[<?= $event_type_arr['id'] ?>]" value="" ?>
                                            <?php } else { ?>
                                                <input type="hidden" name="single_price[<?= $event_type_arr['id'] ?>]"
                                                    value="<?= $event_type_arr['single_price'] ?>" ?>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div id="terms-section-<?= $event_type_arr['id'] ?>"
                                        style="display: none; height: 250px; overflow-y: scroll;border: 1px solid #c5c1c1;padding: 10px;font-size:0.8rem;">
                                        <h5>Terms And Conditions</h5>
                                        <p><?php echo $event_type_arr['tnc']; ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php } ?>

                        <div class="row mb-2">
                            <div class="col-md-6">
                                <div class="total-area mb-2">
                                    <input type="hidden" name="total_amount" id="payment_total">
                                    <div class="quantity-box mb-2">
                                        <label> No Of Tickets : </label>&nbsp;&nbsp;
                                        <!-- <button type="button" onclick="changeQuantity(-1)">-</button> -->
                                        <input type="number" id="quantity" value="1" min="1" class="form-control"
                                            name="no_of_tickets">
                                        <!-- <button type="button" onclick="changeQuantity(1)">+</button> -->
                                    </div>
                                    <div class="amounts">
                                        <div class="amount-item">
                                            <span class="label">Net payable Total:</span>
                                            ₹
                                            <input type="text" id="net_payable_total" name="net_payable_total" value=""
                                                class="form-control" style="width:30%;" readonly>
                                            <!-- <span id="">0.00</span> -->
                                        </div>
                                        <div class="amount-item">
                                            <span class="label">Advance:</span>
                                            ₹<input type="text" id="Advance" value="" class="form-control" name="Advance"
                                                style="width:30%;" readonly>

                                            <input type="hidden" name="advance_amount">
                                        </div>
                                        <div class="amount-item">
                                            <span class="label">Remaining:</span>
                                            ₹<input type="text" id="remaining_amount" value="" name="remaining_amount"
                                                class="form-control" style="width:30%;" readonly>
                                            <!-- <input type="hidden" name="remaining_amount"> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div id="coupon-container">
                                    <div class="field">
                                        <label for="coupon_code">Enter Coupon Code<span
                                                class="required-icon">*</span></label>
                                        <div class="row">
                                            <div class="col-9 jay">
                                                <input type="text" id="coupon_code" name="coupon_code" class="form-control"
                                                    placeholder="Enter coupon code">
                                            </div>
                                            <div class="col-3 d-flex align-items-center">
                                                <button type="button" id="apply-coupon"
                                                    class="btn btn-primary mr-2">Apply</button>
                                                <button type="button" id="cancel-coupon" class="btn btn-danger hide">
                                                    Cancel
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" id="coupon_value" name="coupon_value" class="form-control">
                                <div class="sms">
                                    <p id="coupon-message"></p>
                                </div>
                                <div class="sms">
                                    <p id="coupon-alert"></p>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-md-6">
                                <div class="field">
                                    <label for="payment-ref-no">Payment Reference No <span
                                            class="required-icon">*</span></label>
                                    <input type="text" id="payment-ref-no" name="payment_ref_no"
                                        placeholder="Enter Payment Reference No" class="form-control">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="file-upload-container">
                                    <h3 class="upload-heading">Payment Screenshot<span class="required-marker"> *</span>
                                    </h3>
                                    <div class="file-upload-area">
                                        <input type="file" id="file-upload" name="screenshot" multiple accept="image/*"
                                            class="form-control">
                                        <label for="file-upload" class="upload-button">
                                            <span>Add file</span>
                                        </label>
                                        <div id="selected-files" class="selected-files"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div id="error-messages" style="color: red; font-size: 1rem; margin-bottom: 20px;"></div>

                        <div class="row mb-2">
                            <button type="submit" class="btn btn-primary" onclick="validateForm(event)">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <footer class="footer_v1 ova-trans" style="background:#000;">
        <div class="wrap_widget">
            <div class="container1">
                <div class="row">
                    <div class="col-sm-4 category pd_0 pd_l_0">
                        <div id="media_image-3" class="widget widget_media_image">
                            <img width="150" height="150"
                                src="https://glowupwithmanisha.com/wp-content/uploads/2024/08/file-150x150.jpg"
                                class="image wp-image-12947  attachment-thumbnail size-thumbnail" alt=""
                                style="max-width: 100%; height: auto;" decoding="async" loading="lazy"
                                srcset="https://glowupwithmanisha.com/wp-content/uploads/2024/08/file-150x150.jpg 150w, https://glowupwithmanisha.com/wp-content/uploads/2024/08/file-300x300.jpg 300w, https://glowupwithmanisha.com/wp-content/uploads/2024/08/file-600x600.jpg 600w, https://glowupwithmanisha.com/wp-content/uploads/2024/08/file-100x100.jpg 100w, https://glowupwithmanisha.com/wp-content/uploads/2024/08/file.jpg 640w"
                                sizes="(max-width: 150px) 100vw, 150px">
                        </div>
                    </div>
                    <div class="col-sm-4 gallery pd_0">
                        <div id="custom_html-9" class="widget_text widget widget_custom_html">
                            <h4 class="widget-title">Quick Links</h4>
                            <div class="textwidget custom-html-widget">
                                <ul style="color:white">
                                    <li>
                                        <a href="https://glowupwithmanisha.com/terms-conditions/" target="_blank"
                                            rel="noopener">Terms &amp; conditions</a>
                                    </li>
                                    <li>
                                        <a href="https://glowupwithmanisha.com/privacy-policies/" target="_blank"
                                            rel="noopener">Privacy Policy</a>
                                    </li>
                                    <li>
                                        <a href="https://glowupwithmanisha.com/disclaimer/" target="_blank"
                                            rel="noopener">Legal Disclaimer</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4 tags  pd_0 pd_r_0">
                        <div id="custom_html-4" class="widget_text widget widget_custom_html">
                            <h4 class="widget-title">Contact Details</h4>
                            <div class="textwidget custom-html-widget">
                                <p style="color:white">
                                    <strong>Phone -</strong> +91 98204 90762 / +91 98204 90460
                                </p>
                                <p style="color:white"><strong>Email -</strong> glowupwithmanisha@gmail.com</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="wrap_bellow">
            <div class="container1">
                <div class="row">
                    <div class="col-sm-12 pd_0 logo_white text-center">
                        <div id="custom_html-7" class="widget_text widget widget_custom_html">
                            <div class="textwidget custom-html-widget">
                                <p style="color:white">Copyright ©2024 Glow Up with Manisha, All rights reserved.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </footer>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz4fnFO9bU0DGRpS2L90m0cH0n2AnXL7jF1C2DBcBxrmQ1o5OS7Y3ELDDa" crossorigin="anonymous">
        </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
        integrity="sha384-Tc5G3sS0u5S7nH6j27blOg9Q71GmA0m1m4U2F2mvDlV8z7F3Km/rI4b3r8ewpPpY" crossorigin="anonymous">
        </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function () {

            let totalPrice = 0.00;
            let currentCoupon = "";
            let couponDiscount = 0;
            let totalAmt = 0;

            // Update the total calculation based on selections
            function updateTotal() {
                totalPrice = 0.00;
                // Loop through selected event types and add their prices
                $('input[name^="event_type"]:checked').each(function () {
                    const eventTypeId = $(this).attr('id').split('-')[
                        1]; // Extract event type ID from checkbox ID

                    // Get single price if package is not available
                    const label = $(this).closest('.checkbox-item').find('label').text();
                    const eventPriceMatch = label.match(/₹(\d+)/);
                    // const single_price = parseFloat(eventPriceMatch[1]);
                    if (eventPriceMatch) {
                        totalPrice += parseFloat(eventPriceMatch[1]);
                    }

                    // Check if the event type has a package available
                    const packageSelection = $('#package-selection-' + eventTypeId);
                    if (packageSelection.length > 0) {
                        packageSelection.show(); // Show package selection
                        // Add the selected package fee to the total price
                        const selectedPackage = $('input[name^="package_selection[' + eventTypeId +
                            ']"]:checked');
                        if (selectedPackage.length > 0) {
                            totalPrice += parseFloat(selectedPackage.data('fee'));
                        }

                        $('input[name^="package_amount[' + eventTypeId +
                            ']"]').val(selectedPackage.data('fee'));
                    }

                });
                const qty = $('input[name="no_of_tickets"]').val();
                totalAmt = qty * totalPrice;
                // Calculate advance payment
                const advancePayment = (totalAmt * 50) / 100;
                let paymentTotal = totalAmt;

                console.log('couponDiscount' + couponDiscount);
                // Apply coupon discount if available
                if (couponDiscount > 0) {
                    paymentTotal -= couponDiscount;
                }

                // Calculate remaining amount
                const remainingAmount = Math.max(0, paymentTotal - advancePayment);

                // Update the payment details on the page
                $('#payment_total').val(totalAmt.toFixed(2));
                $('input[name="net_payable_total"]').val(paymentTotal.toFixed(2));
                $('input[name="Advance"]').val(advancePayment.toFixed(2));
                $('input[name="remaining_amount"]').val(remainingAmount.toFixed(2));
                $('input[name="total_amount"]').val(totalPrice);
                $('input[name="advance_amount"]').val(advancePayment);
                $('input[name="remaining_amount"]').val(remainingAmount);
            }

            // Toggle visibility of package selection and terms and conditions based on event type checkbox state
            function toggleTerms(eventTypeId) {
                const checkbox = $('#event-' + eventTypeId);
                const packageSelection = $('#package-selection-' + eventTypeId);
                const termsSection = $('#terms-section-' + eventTypeId);

                if (checkbox.is(':checked')) {
                    packageSelection.show(); // Show package selection if applicable
                    termsSection.show(); // Show TNC section
                } else {
                    packageSelection.hide(); // Hide package selection
                    termsSection.hide(); // Hide TNC section
                }
            }

            // Apply coupon button click handler
            $('#apply-coupon').click(function () {
                const couponCode = $('#coupon_code').val().trim();
                if (couponCode !== currentCoupon) {
                    currentCoupon = couponCode;
                    $.ajax({
                        url: 'verify_coupon.php',
                        type: 'GET',
                        data: {
                            code: couponCode
                        },
                        success: function (response) {
                            const discount = parseFloat(response);
                            let successMessage = '';
                            let errorMessage = '';

                            if (discount > 0 && totalPrice > 0) {
                                $('#coupon_value').val(discount.toFixed(2));
                                successMessage =
                                    `Coupon "${couponCode}" applied successfully! Discount: ₹${discount}`;
                                couponDiscount = discount;

                                updateTotal();
                            } else if (discount === -1) {
                                errorMessage = 'Invalid coupon code. Please try again.';
                            } else if (discount === -2) {
                                errorMessage = 'No coupon code provided.';
                            } else {
                                errorMessage = 'Unexpected response from the server.';
                            }

                            if (successMessage) {
                                $('#coupon-message').text(successMessage).addClass('show');
                                $('#coupon-alert').text('').removeClass('show');
                                $('#cancel-coupon').removeClass('hide');
                            } else if (errorMessage) {
                                $('#coupon-alert').text(errorMessage).addClass('show');
                                $('#coupon-message').text('').removeClass('show');
                                $('#cancel-coupon').addClass('show');
                            }
                        },
                        error: function () {
                            $('#coupon-alert').text('An error occurred. Please try again.')
                                .addClass('show');
                            $('#coupon-message').text('').removeClass('show');
                        }
                    });
                } else {
                    $('#coupon-alert').text('Coupon code already applied').addClass('show');
                    $('#coupon-message').text('').removeClass('show');
                }
            });

            // Cancel coupon button click handler
            $('#cancel-coupon').click(function () {
                if (currentCoupon) {
                    $('#coupon_code').val('');
                    $('#coupon-message').text('').removeClass('show');
                    $('#coupon-alert').text('').removeClass('show');
                    couponDiscount = 0;
                    currentCoupon = '';
                    $('#coupon_value').val('');
                    updateTotal();
                    $('#cancel-coupon').addClass('hide');
                } else {
                    $('#coupon-alert').text('No coupon code applied to cancel.').addClass('show');
                    $('#coupon-message').text('').removeClass('show');
                    $('#cancel-coupon').addClass('hide');
                }
            });
            $(document).ready(function () {
                $('#apply-coupon').on('click', function () {
                    var couponCode = $('#coupon_code').val();

                    // If coupon code is entered, show the Cancel button
                    if (couponCode) {
                        $('#cancel-coupon').removeClass('hide');
                    } else {
                        $('#cancel-coupon').addClass('hide');
                    }
                });

                $('#cancel-coupon').on('click', function () {
                    // Clear the coupon code and hide the Cancel button
                    $('#coupon_code').val('');
                    $('#cancel-coupon').addClass('hide');
                });
            });

            // Event listeners for checkboxes and radio buttons
            $('input[name^="event_type"]').on('change', function () {
                const eventTypeId = $(this).attr('id').split('-')[1];
                toggleTerms(eventTypeId);
                updateTotal();
            });

            $('input[name^="package_selection"]').on('change', updateTotal);
            $('input[name^="no_of_tickets"]').on('input', updateTotal);

            // Download QR code button handler
            document.getElementById('download-qr').addEventListener('click', function () {
                const qrCodeUrl = 'QR-Code.png';
                const link = document.createElement('a');
                link.href = qrCodeUrl;
                link.download = '';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            });

            // File upload handler
            document.getElementById('file-upload').addEventListener('change', function (event) {
                const files = event.target.files;
                const selectedFilesContainer = document.getElementById('selected-files');
                selectedFilesContainer.innerHTML = '';

                Array.from(files).forEach(file => {
                    if (file.type.startsWith('image/')) {
                        const reader = new FileReader();
                        reader.onload = function (e) {
                            const img = document.createElement('img');
                            img.src = e.target.result;
                            img.alt = file.name;
                            img.title = file.name;
                            img.style.maxWidth = '150px';
                            img.style.maxHeight = '150px';

                            const removeBtn = document.createElement('button');
                            removeBtn.textContent = 'Remove';
                            removeBtn.className = 'remove-btn';
                            removeBtn.onclick = function () {
                                selectedFilesContainer.removeChild(img);
                                selectedFilesContainer.removeChild(removeBtn);

                                if (selectedFilesContainer.children.length === 0) {
                                    document.getElementById('file-upload').value = '';
                                }
                            };

                            selectedFilesContainer.appendChild(img);
                            selectedFilesContainer.appendChild(removeBtn);
                        };
                        reader.readAsDataURL(file);
                    } else {
                        alert('Please select an image file.');
                    }
                });
            });

            // Change handlers for select elements
            document.getElementById('area-interest').addEventListener('change', function () {
                const areaInterestOthersInput = document.getElementById('category-others');
                areaInterestOthersInput.style.display = (this.value === 'Others') ? 'block' : 'none';
                if (this.value !== 'Others') {
                    areaInterestOthersInput.value = '';
                }
            });

            document.getElementById('lead-source').addEventListener('change', function () {
                const leadSourceOthersInput = document.getElementById('lead-source-others');
                leadSourceOthersInput.style.display = (this.value === 'Others') ? 'block' : 'none';
                if (this.value !== 'Others') {
                    leadSourceOthersInput.value = '';
                }
            });
        });
    </script>
    <script>
        document.querySelector('form').addEventListener('submit', function (event) {
            var errorMessages = []; // To store error messages
            var bookingDate = document.getElementById('booking_date').value;
            var eventTypeChecked = false;

            // Check if any event type checkbox is checked
            document.querySelectorAll('input[name^="event_type"]:checked').forEach(function (checkbox) {
                if (checkbox.checked) {
                    eventTypeChecked = true;

                    // Check if the selected event type has packages
                    var eventId = checkbox.id.split('-')[1]; // Get the event ID from checkbox ID (e.g., event-1)
                    var packageSelected = false;

                    // Check if packages are available for the event type and ensure one is selected
                    if (document.getElementById('package-selection-' + eventId)) {
                        var selectedPackage = document.querySelector('input[name="package_selection[' + eventId + ']"]:checked');
                        if (selectedPackage) {
                            packageSelected = true;
                        }
                    }

                    // If event has packages and no package is selected, add error
                    if (!packageSelected && document.getElementById('package-selection-' + eventId)) {
                        errorMessages.push("Please select a package for " + checkbox.value + ".");
                    }
                }
            });

            // Clear any previous error messages
            document.getElementById('error-messages').innerHTML = '';

            // If booking date is not selected, add an error message
            if (!bookingDate) {
                errorMessages.push("Please select a booking date.");
            }

            // If no event type is selected, add an error message
            if (!eventTypeChecked) {
                errorMessages.push("Please select at least one event type.");
            }

            // If there are errors, prevent form submission and display the errors
            if (errorMessages.length > 0) {
                event.preventDefault(); // Prevent form submission

                // Display errors in the #error-messages div
                var errorHtml = '<ul>';
                errorMessages.forEach(function (message) {
                    errorHtml += '<li>' + message + '</li>';
                });
                errorHtml += '</ul>';

                document.getElementById('error-messages').innerHTML = errorHtml;
            }
        });
    </script>
    <script>
        document.getElementById('apply-coupon').addEventListener('click', function () {
            var couponInput = document.getElementById('coupon_code');
            couponInput.setAttribute('readonly', true); // Make input readonly
            document.getElementById('apply-coupon').disabled = true; // Disable the apply button
            document.getElementById('apply-coupon').style.display = 'none'; // Hide the apply button

            // Optionally, show the cancel button after the coupon is applied
            document.getElementById('cancel-coupon').style.display = 'inline-block'; // Show the cancel button
        });

        // Optional: If you want to remove the readonly status and show the Apply button again when the cancel button is clicked
        document.getElementById('cancel-coupon').addEventListener('click', function () {
            var couponInput = document.getElementById('coupon_code');
            couponInput.removeAttribute('readonly'); // Remove readonly status
            document.getElementById('apply-coupon').disabled = false; // Enable the apply button
            document.getElementById('apply-coupon').style.display = 'inline-block'; // Show the apply button again
            document.getElementById('cancel-coupon').style.display = 'none'; // Hide the cancel button
        });

    $(document).ready(function () {
    $('.qr_btn').on('click', async function () {
        // Get the image URL
        const qrCodeUrl = $(this).closest('.qr_image').find('img').attr('src');
        
        console.log('QR Code URL:', qrCodeUrl); // Debugging

        if (!qrCodeUrl) {
            alert('Image URL not found!');
            return;
        }

        try {
            // Fetch the image
            const response = await fetch(qrCodeUrl);

            // Check if the response is okay
            if (!response.ok) throw new Error('Failed to fetch the image');

            // Convert response to a Blob
            const blob = await response.blob();

            // Create a temporary object URL
            const blobUrl = URL.createObjectURL(blob);

            // Create a downloadable link
            const link = document.createElement('a');
            link.href = blobUrl;
            link.download = qrCodeUrl.split('/').pop(); // Extract filename from URL
            document.body.appendChild(link);
            link.click();

            // Clean up
            document.body.removeChild(link);
            URL.revokeObjectURL(blobUrl); // Free memory
        } catch (error) {
            console.error('Error downloading the image:', error);
            alert('Failed to download the image. Please try again later.');
        }
    });
});

    </script>
</body>

</html>